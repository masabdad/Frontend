﻿namespace Cafe_Management_Systems
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtIcedCapp = new System.Windows.Forms.TextBox();
            this.txtAfrican = new System.Windows.Forms.TextBox();
            this.txtCapp = new System.Windows.Forms.TextBox();
            this.txtVale = new System.Windows.Forms.TextBox();
            this.txtIcedLatte = new System.Windows.Forms.TextBox();
            this.txtEspresso = new System.Windows.Forms.TextBox();
            this.txtLate = new System.Windows.Forms.TextBox();
            this.chkIcedCap = new System.Windows.Forms.CheckBox();
            this.chkAfrican = new System.Windows.Forms.CheckBox();
            this.chkCappuccino = new System.Windows.Forms.CheckBox();
            this.chkVale = new System.Windows.Forms.CheckBox();
            this.chkIcedLatte = new System.Windows.Forms.CheckBox();
            this.chkEspresso = new System.Windows.Forms.CheckBox();
            this.chkLatte = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtCarlton = new System.Windows.Forms.TextBox();
            this.txtKilburn = new System.Windows.Forms.TextBox();
            this.txtLagos = new System.Windows.Forms.TextBox();
            this.txtBoston = new System.Windows.Forms.TextBox();
            this.txtBlack = new System.Windows.Forms.TextBox();
            this.txtRed = new System.Windows.Forms.TextBox();
            this.txtCoffee = new System.Windows.Forms.TextBox();
            this.chkKilburn = new System.Windows.Forms.CheckBox();
            this.chkRedValvet = new System.Windows.Forms.CheckBox();
            this.chkLagos = new System.Windows.Forms.CheckBox();
            this.chkBoston = new System.Windows.Forms.CheckBox();
            this.chkCarlton = new System.Windows.Forms.CheckBox();
            this.chkBlack = new System.Windows.Forms.CheckBox();
            this.chkCoffee = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rtfReceipt = new System.Windows.Forms.RichTextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblCharge = new System.Windows.Forms.Label();
            this.lblCake = new System.Windows.Forms.Label();
            this.lblDrink = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblCostCake = new System.Windows.Forms.Label();
            this.lblCostDrink = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblSubTotal = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.lblTime);
            this.panel1.Controls.Add(this.lblDate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1328, 100);
            this.panel1.TabIndex = 0;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTime.Location = new System.Drawing.Point(6, 81);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(41, 13);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "label4";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDate.Location = new System.Drawing.Point(1185, 80);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(41, 13);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "label3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Webdings", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(0, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(274, 80);
            this.label2.TabIndex = 1;
            this.label2.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(286, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1042, 91);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cafe Management Systems";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.txtIcedCapp);
            this.panel2.Controls.Add(this.txtAfrican);
            this.panel2.Controls.Add(this.txtCapp);
            this.panel2.Controls.Add(this.txtVale);
            this.panel2.Controls.Add(this.txtIcedLatte);
            this.panel2.Controls.Add(this.txtEspresso);
            this.panel2.Controls.Add(this.txtLate);
            this.panel2.Controls.Add(this.chkIcedCap);
            this.panel2.Controls.Add(this.chkAfrican);
            this.panel2.Controls.Add(this.chkCappuccino);
            this.panel2.Controls.Add(this.chkVale);
            this.panel2.Controls.Add(this.chkIcedLatte);
            this.panel2.Controls.Add(this.chkEspresso);
            this.panel2.Controls.Add(this.chkLatte);
            this.panel2.Location = new System.Drawing.Point(12, 118);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(481, 280);
            this.panel2.TabIndex = 1;
            // 
            // txtIcedCapp
            // 
            this.txtIcedCapp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIcedCapp.Location = new System.Drawing.Point(341, 206);
            this.txtIcedCapp.Multiline = true;
            this.txtIcedCapp.Name = "txtIcedCapp";
            this.txtIcedCapp.Size = new System.Drawing.Size(123, 26);
            this.txtIcedCapp.TabIndex = 14;
            this.txtIcedCapp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtIcedCapp.Click += new System.EventHandler(this.txtIcedCapp_Click);
            // 
            // txtAfrican
            // 
            this.txtAfrican.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAfrican.Location = new System.Drawing.Point(341, 174);
            this.txtAfrican.Multiline = true;
            this.txtAfrican.Name = "txtAfrican";
            this.txtAfrican.Size = new System.Drawing.Size(123, 26);
            this.txtAfrican.TabIndex = 13;
            this.txtAfrican.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAfrican.Click += new System.EventHandler(this.txtAfrican_Click);
            // 
            // txtCapp
            // 
            this.txtCapp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCapp.Location = new System.Drawing.Point(341, 142);
            this.txtCapp.Multiline = true;
            this.txtCapp.Name = "txtCapp";
            this.txtCapp.Size = new System.Drawing.Size(123, 26);
            this.txtCapp.TabIndex = 12;
            this.txtCapp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCapp.Click += new System.EventHandler(this.txtCapp_Click);
            // 
            // txtVale
            // 
            this.txtVale.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVale.Location = new System.Drawing.Point(341, 110);
            this.txtVale.Multiline = true;
            this.txtVale.Name = "txtVale";
            this.txtVale.Size = new System.Drawing.Size(123, 26);
            this.txtVale.TabIndex = 11;
            this.txtVale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtVale.Click += new System.EventHandler(this.txtVale_Click);
            // 
            // txtIcedLatte
            // 
            this.txtIcedLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIcedLatte.Location = new System.Drawing.Point(341, 78);
            this.txtIcedLatte.Multiline = true;
            this.txtIcedLatte.Name = "txtIcedLatte";
            this.txtIcedLatte.Size = new System.Drawing.Size(123, 25);
            this.txtIcedLatte.TabIndex = 10;
            this.txtIcedLatte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtIcedLatte.Click += new System.EventHandler(this.txtIcedLatte_Click);
            // 
            // txtEspresso
            // 
            this.txtEspresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEspresso.Location = new System.Drawing.Point(341, 45);
            this.txtEspresso.Multiline = true;
            this.txtEspresso.Name = "txtEspresso";
            this.txtEspresso.Size = new System.Drawing.Size(123, 25);
            this.txtEspresso.TabIndex = 9;
            this.txtEspresso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtEspresso.Click += new System.EventHandler(this.txtEspresso_Click);
            // 
            // txtLate
            // 
            this.txtLate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLate.Location = new System.Drawing.Point(341, 12);
            this.txtLate.Multiline = true;
            this.txtLate.Name = "txtLate";
            this.txtLate.Size = new System.Drawing.Size(123, 24);
            this.txtLate.TabIndex = 8;
            this.txtLate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLate.Click += new System.EventHandler(this.txtLate_Click);
            // 
            // chkIcedCap
            // 
            this.chkIcedCap.AutoSize = true;
            this.chkIcedCap.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIcedCap.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkIcedCap.Location = new System.Drawing.Point(14, 194);
            this.chkIcedCap.Name = "chkIcedCap";
            this.chkIcedCap.Size = new System.Drawing.Size(173, 24);
            this.chkIcedCap.TabIndex = 7;
            this.chkIcedCap.Text = "Iced - Cappuccino";
            this.chkIcedCap.UseVisualStyleBackColor = true;
            this.chkIcedCap.CheckedChanged += new System.EventHandler(this.chkIcedCap_CheckedChanged);
            // 
            // chkAfrican
            // 
            this.chkAfrican.AutoSize = true;
            this.chkAfrican.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAfrican.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkAfrican.Location = new System.Drawing.Point(14, 164);
            this.chkAfrican.Name = "chkAfrican";
            this.chkAfrican.Size = new System.Drawing.Size(144, 24);
            this.chkAfrican.TabIndex = 6;
            this.chkAfrican.Text = "African Coffee";
            this.chkAfrican.UseVisualStyleBackColor = true;
            this.chkAfrican.CheckedChanged += new System.EventHandler(this.chkAfrican_CheckedChanged);
            // 
            // chkCappuccino
            // 
            this.chkCappuccino.AutoSize = true;
            this.chkCappuccino.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCappuccino.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkCappuccino.Location = new System.Drawing.Point(14, 134);
            this.chkCappuccino.Name = "chkCappuccino";
            this.chkCappuccino.Size = new System.Drawing.Size(122, 24);
            this.chkCappuccino.TabIndex = 5;
            this.chkCappuccino.Text = "Cappuccino";
            this.chkCappuccino.UseVisualStyleBackColor = true;
            this.chkCappuccino.CheckedChanged += new System.EventHandler(this.chkCappuccino_CheckedChanged);
            // 
            // chkVale
            // 
            this.chkVale.AutoSize = true;
            this.chkVale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkVale.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkVale.Location = new System.Drawing.Point(14, 103);
            this.chkVale.Name = "chkVale";
            this.chkVale.Size = new System.Drawing.Size(123, 24);
            this.chkVale.TabIndex = 3;
            this.chkVale.Text = "Vale Coffee";
            this.chkVale.UseVisualStyleBackColor = true;
            this.chkVale.CheckedChanged += new System.EventHandler(this.chkVale_CheckedChanged);
            // 
            // chkIcedLatte
            // 
            this.chkIcedLatte.AutoSize = true;
            this.chkIcedLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIcedLatte.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkIcedLatte.Location = new System.Drawing.Point(14, 73);
            this.chkIcedLatte.Name = "chkIcedLatte";
            this.chkIcedLatte.Size = new System.Drawing.Size(110, 24);
            this.chkIcedLatte.TabIndex = 2;
            this.chkIcedLatte.Text = "Iced Latte";
            this.chkIcedLatte.UseVisualStyleBackColor = true;
            this.chkIcedLatte.CheckedChanged += new System.EventHandler(this.chkIcedLatte_CheckedChanged);
            // 
            // chkEspresso
            // 
            this.chkEspresso.AutoSize = true;
            this.chkEspresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEspresso.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkEspresso.Location = new System.Drawing.Point(14, 43);
            this.chkEspresso.Name = "chkEspresso";
            this.chkEspresso.Size = new System.Drawing.Size(103, 24);
            this.chkEspresso.TabIndex = 1;
            this.chkEspresso.Text = "Espresso";
            this.chkEspresso.UseVisualStyleBackColor = true;
            this.chkEspresso.CheckedChanged += new System.EventHandler(this.chkEspresso_CheckedChanged);
            // 
            // chkLatte
            // 
            this.chkLatte.AutoSize = true;
            this.chkLatte.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLatte.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkLatte.Location = new System.Drawing.Point(14, 13);
            this.chkLatte.Name = "chkLatte";
            this.chkLatte.Size = new System.Drawing.Size(70, 24);
            this.chkLatte.TabIndex = 0;
            this.chkLatte.Text = "Latte";
            this.chkLatte.UseVisualStyleBackColor = true;
            this.chkLatte.CheckedChanged += new System.EventHandler(this.chkLatte_CheckedChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel3.Controls.Add(this.txtCarlton);
            this.panel3.Controls.Add(this.txtKilburn);
            this.panel3.Controls.Add(this.txtLagos);
            this.panel3.Controls.Add(this.txtBoston);
            this.panel3.Controls.Add(this.txtBlack);
            this.panel3.Controls.Add(this.txtRed);
            this.panel3.Controls.Add(this.txtCoffee);
            this.panel3.Controls.Add(this.chkKilburn);
            this.panel3.Controls.Add(this.chkRedValvet);
            this.panel3.Controls.Add(this.chkLagos);
            this.panel3.Controls.Add(this.chkBoston);
            this.panel3.Controls.Add(this.chkCarlton);
            this.panel3.Controls.Add(this.chkBlack);
            this.panel3.Controls.Add(this.chkCoffee);
            this.panel3.Location = new System.Drawing.Point(499, 118);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(503, 280);
            this.panel3.TabIndex = 2;
            // 
            // txtCarlton
            // 
            this.txtCarlton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCarlton.Location = new System.Drawing.Point(339, 206);
            this.txtCarlton.Multiline = true;
            this.txtCarlton.Name = "txtCarlton";
            this.txtCarlton.Size = new System.Drawing.Size(123, 26);
            this.txtCarlton.TabIndex = 21;
            this.txtCarlton.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCarlton.Click += new System.EventHandler(this.txtCarlton_Click);
            // 
            // txtKilburn
            // 
            this.txtKilburn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKilburn.Location = new System.Drawing.Point(339, 174);
            this.txtKilburn.Multiline = true;
            this.txtKilburn.Name = "txtKilburn";
            this.txtKilburn.Size = new System.Drawing.Size(123, 26);
            this.txtKilburn.TabIndex = 20;
            this.txtKilburn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtKilburn.Click += new System.EventHandler(this.txtKilburn_Click);
            // 
            // txtLagos
            // 
            this.txtLagos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLagos.Location = new System.Drawing.Point(339, 142);
            this.txtLagos.Multiline = true;
            this.txtLagos.Name = "txtLagos";
            this.txtLagos.Size = new System.Drawing.Size(123, 26);
            this.txtLagos.TabIndex = 19;
            this.txtLagos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLagos.Click += new System.EventHandler(this.txtLagos_Click);
            // 
            // txtBoston
            // 
            this.txtBoston.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoston.Location = new System.Drawing.Point(339, 110);
            this.txtBoston.Multiline = true;
            this.txtBoston.Name = "txtBoston";
            this.txtBoston.Size = new System.Drawing.Size(123, 26);
            this.txtBoston.TabIndex = 18;
            this.txtBoston.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBoston.Click += new System.EventHandler(this.txtBoston_Click);
            // 
            // txtBlack
            // 
            this.txtBlack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBlack.Location = new System.Drawing.Point(339, 78);
            this.txtBlack.Multiline = true;
            this.txtBlack.Name = "txtBlack";
            this.txtBlack.Size = new System.Drawing.Size(123, 26);
            this.txtBlack.TabIndex = 17;
            this.txtBlack.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBlack.Click += new System.EventHandler(this.txtBlack_Click);
            // 
            // txtRed
            // 
            this.txtRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRed.Location = new System.Drawing.Point(339, 44);
            this.txtRed.Multiline = true;
            this.txtRed.Name = "txtRed";
            this.txtRed.Size = new System.Drawing.Size(123, 26);
            this.txtRed.TabIndex = 16;
            this.txtRed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRed.Click += new System.EventHandler(this.txtRed_Click);
            // 
            // txtCoffee
            // 
            this.txtCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCoffee.Location = new System.Drawing.Point(339, 12);
            this.txtCoffee.Multiline = true;
            this.txtCoffee.Name = "txtCoffee";
            this.txtCoffee.Size = new System.Drawing.Size(123, 26);
            this.txtCoffee.TabIndex = 15;
            this.txtCoffee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCoffee.Click += new System.EventHandler(this.txtCoffee_Click);
            // 
            // chkKilburn
            // 
            this.chkKilburn.AutoSize = true;
            this.chkKilburn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkKilburn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkKilburn.Location = new System.Drawing.Point(17, 163);
            this.chkKilburn.Name = "chkKilburn";
            this.chkKilburn.Size = new System.Drawing.Size(215, 24);
            this.chkKilburn.TabIndex = 15;
            this.chkKilburn.Text = "Kilburn Chocolate Cake";
            this.chkKilburn.UseVisualStyleBackColor = true;
            this.chkKilburn.CheckedChanged += new System.EventHandler(this.chkKilburn_CheckedChanged);
            // 
            // chkRedValvet
            // 
            this.chkRedValvet.AutoSize = true;
            this.chkRedValvet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRedValvet.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkRedValvet.Location = new System.Drawing.Point(17, 42);
            this.chkRedValvet.Name = "chkRedValvet";
            this.chkRedValvet.Size = new System.Drawing.Size(162, 24);
            this.chkRedValvet.TabIndex = 11;
            this.chkRedValvet.Text = "Red Velvet Cake";
            this.chkRedValvet.UseVisualStyleBackColor = true;
            this.chkRedValvet.CheckedChanged += new System.EventHandler(this.chkRedValvet_CheckedChanged);
            // 
            // chkLagos
            // 
            this.chkLagos.AutoSize = true;
            this.chkLagos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLagos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkLagos.Location = new System.Drawing.Point(17, 133);
            this.chkLagos.Name = "chkLagos";
            this.chkLagos.Size = new System.Drawing.Size(214, 24);
            this.chkLagos.TabIndex = 14;
            this.chkLagos.Text = "Lagos Chocolate Cake ";
            this.chkLagos.UseVisualStyleBackColor = true;
            this.chkLagos.CheckedChanged += new System.EventHandler(this.chkLagos_CheckedChanged);
            // 
            // chkBoston
            // 
            this.chkBoston.AutoSize = true;
            this.chkBoston.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBoston.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkBoston.Location = new System.Drawing.Point(17, 103);
            this.chkBoston.Name = "chkBoston";
            this.chkBoston.Size = new System.Drawing.Size(188, 24);
            this.chkBoston.TabIndex = 13;
            this.chkBoston.Text = "Boston Cream Cake";
            this.chkBoston.UseVisualStyleBackColor = true;
            this.chkBoston.CheckedChanged += new System.EventHandler(this.chkBoston_CheckedChanged);
            // 
            // chkCarlton
            // 
            this.chkCarlton.AutoSize = true;
            this.chkCarlton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCarlton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkCarlton.Location = new System.Drawing.Point(17, 193);
            this.chkCarlton.Name = "chkCarlton";
            this.chkCarlton.Size = new System.Drawing.Size(248, 24);
            this.chkCarlton.TabIndex = 4;
            this.chkCarlton.Text = "Carlton Hill Chocolate Cake";
            this.chkCarlton.UseVisualStyleBackColor = true;
            this.chkCarlton.CheckedChanged += new System.EventHandler(this.chkCarlton_CheckedChanged);
            // 
            // chkBlack
            // 
            this.chkBlack.AutoSize = true;
            this.chkBlack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBlack.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkBlack.Location = new System.Drawing.Point(17, 73);
            this.chkBlack.Name = "chkBlack";
            this.chkBlack.Size = new System.Drawing.Size(175, 24);
            this.chkBlack.TabIndex = 12;
            this.chkBlack.Text = "Black Forest Cake";
            this.chkBlack.UseVisualStyleBackColor = true;
            this.chkBlack.CheckedChanged += new System.EventHandler(this.chkBlack_CheckedChanged);
            // 
            // chkCoffee
            // 
            this.chkCoffee.AutoSize = true;
            this.chkCoffee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCoffee.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.chkCoffee.Location = new System.Drawing.Point(17, 12);
            this.chkCoffee.Name = "chkCoffee";
            this.chkCoffee.Size = new System.Drawing.Size(128, 24);
            this.chkCoffee.TabIndex = 10;
            this.chkCoffee.Text = "Coffee Cake";
            this.chkCoffee.UseVisualStyleBackColor = true;
            this.chkCoffee.CheckedChanged += new System.EventHandler(this.chkCoffee_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel4.Controls.Add(this.toolStrip1);
            this.panel4.Controls.Add(this.rtfReceipt);
            this.panel4.Location = new System.Drawing.Point(1008, 118);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(332, 455);
            this.panel4.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripButton,
            this.openToolStripButton,
            this.saveToolStripButton,
            this.printToolStripButton,
            this.toolStripSeparator,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.toolStripSeparator1,
            this.helpToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(332, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // newToolStripButton
            // 
            this.newToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripButton.Image")));
            this.newToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newToolStripButton.Name = "newToolStripButton";
            this.newToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.newToolStripButton.Text = "&New";
            this.newToolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripButton.Image")));
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.openToolStripButton.Text = "&Open";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripButton.Image")));
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveToolStripButton.Text = "&Save";
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // printToolStripButton
            // 
            this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
            this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printToolStripButton.Name = "printToolStripButton";
            this.printToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.printToolStripButton.Text = "&Print";
            this.printToolStripButton.Click += new System.EventHandler(this.printToolStripButton_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // cutToolStripButton
            // 
            this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
            this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripButton.Name = "cutToolStripButton";
            this.cutToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cutToolStripButton.Text = "C&ut";
            this.cutToolStripButton.Click += new System.EventHandler(this.cutToolStripButton_Click);
            // 
            // copyToolStripButton
            // 
            this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
            this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripButton.Name = "copyToolStripButton";
            this.copyToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.copyToolStripButton.Text = "&Copy";
            this.copyToolStripButton.Click += new System.EventHandler(this.copyToolStripButton_Click);
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.pasteToolStripButton.Text = "&Paste";
            this.pasteToolStripButton.Click += new System.EventHandler(this.pasteToolStripButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // helpToolStripButton
            // 
            this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
            this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.helpToolStripButton.Name = "helpToolStripButton";
            this.helpToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.helpToolStripButton.Text = "He&lp";
            // 
            // rtfReceipt
            // 
            this.rtfReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtfReceipt.Location = new System.Drawing.Point(3, 28);
            this.rtfReceipt.Name = "rtfReceipt";
            this.rtfReceipt.Size = new System.Drawing.Size(324, 419);
            this.rtfReceipt.TabIndex = 0;
            this.rtfReceipt.Text = "";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel5.Controls.Add(this.lblCharge);
            this.panel5.Controls.Add(this.lblCake);
            this.panel5.Controls.Add(this.lblDrink);
            this.panel5.Controls.Add(this.lblService);
            this.panel5.Controls.Add(this.lblCostCake);
            this.panel5.Controls.Add(this.lblCostDrink);
            this.panel5.Location = new System.Drawing.Point(12, 404);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(481, 275);
            this.panel5.TabIndex = 2;
            // 
            // lblCharge
            // 
            this.lblCharge.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCharge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCharge.Location = new System.Drawing.Point(246, 196);
            this.lblCharge.Name = "lblCharge";
            this.lblCharge.Size = new System.Drawing.Size(195, 46);
            this.lblCharge.TabIndex = 5;
            this.lblCharge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCake
            // 
            this.lblCake.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCake.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCake.Location = new System.Drawing.Point(246, 115);
            this.lblCake.Name = "lblCake";
            this.lblCake.Size = new System.Drawing.Size(195, 46);
            this.lblCake.TabIndex = 4;
            this.lblCake.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDrink
            // 
            this.lblDrink.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDrink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDrink.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDrink.Location = new System.Drawing.Point(246, 49);
            this.lblDrink.Name = "lblDrink";
            this.lblDrink.Size = new System.Drawing.Size(195, 46);
            this.lblDrink.TabIndex = 3;
            this.lblDrink.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblService.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblService.Location = new System.Drawing.Point(32, 207);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(174, 25);
            this.lblService.TabIndex = 2;
            this.lblService.Text = "Service Charge";
            // 
            // lblCostCake
            // 
            this.lblCostCake.AutoSize = true;
            this.lblCostCake.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostCake.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCostCake.Location = new System.Drawing.Point(32, 126);
            this.lblCostCake.Name = "lblCostCake";
            this.lblCostCake.Size = new System.Drawing.Size(160, 25);
            this.lblCostCake.TabIndex = 1;
            this.lblCostCake.Text = "Cost of Cakes";
            // 
            // lblCostDrink
            // 
            this.lblCostDrink.AutoSize = true;
            this.lblCostDrink.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostDrink.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCostDrink.Location = new System.Drawing.Point(32, 60);
            this.lblCostDrink.Name = "lblCostDrink";
            this.lblCostDrink.Size = new System.Drawing.Size(161, 25);
            this.lblCostDrink.TabIndex = 0;
            this.lblCostDrink.Text = "Cost of Drinks";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel6.Controls.Add(this.lblTotal);
            this.panel6.Controls.Add(this.lblSubTotal);
            this.panel6.Controls.Add(this.lblTax);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Location = new System.Drawing.Point(499, 404);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(503, 275);
            this.panel6.TabIndex = 2;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // lblTotal
            // 
            this.lblTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(267, 196);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(195, 46);
            this.lblTotal.TabIndex = 11;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSubTotal
            // 
            this.lblSubTotal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTotal.Location = new System.Drawing.Point(267, 115);
            this.lblSubTotal.Name = "lblSubTotal";
            this.lblSubTotal.Size = new System.Drawing.Size(195, 46);
            this.lblSubTotal.TabIndex = 10;
            this.lblSubTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTax
            // 
            this.lblTax.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.Location = new System.Drawing.Point(267, 49);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(195, 46);
            this.lblTax.TabIndex = 9;
            this.lblTax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(36, 207);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 25);
            this.label11.TabIndex = 8;
            this.label11.Text = "Total";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(36, 126);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 25);
            this.label10.TabIndex = 7;
            this.label10.Text = "SubTotal";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(36, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 25);
            this.label9.TabIndex = 6;
            this.label9.Text = "Tax";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel7.Controls.Add(this.btnExit);
            this.panel7.Controls.Add(this.btnReset);
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.btnTotal);
            this.panel7.Location = new System.Drawing.Point(1008, 579);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(332, 100);
            this.panel7.TabIndex = 2;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(256, 39);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(73, 38);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(173, 39);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(83, 38);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(75, 39);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 38);
            this.button2.TabIndex = 1;
            this.button2.Text = "Receipt";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.Location = new System.Drawing.Point(1, 39);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(74, 38);
            this.btnTotal.TabIndex = 0;
            this.btnTotal.Text = "Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // Timer1
            // 
            this.Timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1352, 691);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkIcedCap;
        private System.Windows.Forms.CheckBox chkAfrican;
        private System.Windows.Forms.CheckBox chkCappuccino;
        private System.Windows.Forms.CheckBox chkCarlton;
        private System.Windows.Forms.CheckBox chkVale;
        private System.Windows.Forms.CheckBox chkIcedLatte;
        private System.Windows.Forms.CheckBox chkEspresso;
        private System.Windows.Forms.CheckBox chkLatte;
        private System.Windows.Forms.CheckBox chkKilburn;
        private System.Windows.Forms.CheckBox chkRedValvet;
        private System.Windows.Forms.CheckBox chkLagos;
        private System.Windows.Forms.CheckBox chkBoston;
        private System.Windows.Forms.CheckBox chkBlack;
        private System.Windows.Forms.CheckBox chkCoffee;
        private System.Windows.Forms.Label lblCharge;
        private System.Windows.Forms.Label lblCake;
        private System.Windows.Forms.Label lblDrink;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.Label lblCostCake;
        private System.Windows.Forms.Label lblCostDrink;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblSubTotal;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtIcedCapp;
        private System.Windows.Forms.TextBox txtAfrican;
        private System.Windows.Forms.TextBox txtCapp;
        private System.Windows.Forms.TextBox txtVale;
        private System.Windows.Forms.TextBox txtIcedLatte;
        private System.Windows.Forms.TextBox txtEspresso;
        private System.Windows.Forms.TextBox txtLate;
        private System.Windows.Forms.TextBox txtCarlton;
        private System.Windows.Forms.TextBox txtKilburn;
        private System.Windows.Forms.TextBox txtLagos;
        private System.Windows.Forms.TextBox txtBoston;
        private System.Windows.Forms.TextBox txtBlack;
        private System.Windows.Forms.TextBox txtRed;
        private System.Windows.Forms.TextBox txtCoffee;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.RichTextBox rtfReceipt;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton newToolStripButton;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.ToolStripButton printToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton helpToolStripButton;
        private System.Windows.Forms.Timer Timer1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}

